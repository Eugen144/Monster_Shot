let vkData = null; 
let sdkReadySent = false;
let soundEnabled = true;
let progressSaveTimer = null;
let nextLevelLock = false;
let lastSavedData = null;
let vkAvailable = false;

function notifyGameReady() {
    if (sdkReadySent) return;
    sdkReadySent = true;
}

function doSave() {
    if (game.mode === 'survival') return;

    const data = {
        level: game.level, totalCoins: game.totalCoins, upgrades: game.upgrades,
        ownedWeapons: game.player ? game.player.ownedWeapons.slice() : ['pistol'],
        currentWeapon: game.player ? game.player.currentWeapon : 'pistol',
		weaponHintSeen: game.weaponHintSeen // ← добавить
    };
    
    game.savedProgress = data; 
    const dataStr = JSON.stringify(data);
    if (lastSavedData === dataStr) return;

    // ФИКС: обновляем lastSavedData сразу после localStorage — работает и без VK.
    // Если localStorage упал (quota), lastSavedData не обновится, и следующая попытка снова сработает.
    try {
        localStorage.setItem('monster_shot_save', dataStr);
        lastSavedData = dataStr;
    } catch (e) {}

    if (vkAvailable && window.vkBridge) {
        window.vkBridge.send('VKWebAppStorageSet', { key: 'monster_shot_save', value: dataStr })
            .catch(e => console.log('VK Save Error:', e));
    }
}

function saveProgress(immediate = false) {
    if (immediate) {
        if (progressSaveTimer) { clearTimeout(progressSaveTimer); progressSaveTimer = null; }
        doSave(); return;
    }
    if (progressSaveTimer) return;
    progressSaveTimer = setTimeout(() => { progressSaveTimer = null; doSave(); }, 2000);
}

function loadProgress() {
    try {
        const local = localStorage.getItem('monster_shot_save');
        if (local) {
            const parsed = JSON.parse(local);
            if (parsed.level !== undefined) {
                lastSavedData = local;
                return Promise.resolve(parsed);
            }
        }
    } catch (e) {
        console.log('Local load parse error:', e);
    }

    if (vkAvailable && window.vkBridge) {
        return window.vkBridge.send('VKWebAppStorageGet', { keys: ['monster_shot_save'] })
            .then(response => {
                if (response.keys && response.keys.length > 0 && response.keys[0].value) {
                    try {
                        const data = JSON.parse(response.keys[0].value);
                        if (data.level !== undefined) {
                            lastSavedData = response.keys[0].value;
                            try { localStorage.setItem('monster_shot_save', lastSavedData); } catch(e) {}
                            return data;
                        }
                    } catch (e) {
                        console.log('VK load parse error:', e);
                    }
                }
                return null;
            })
            .catch(e => { console.log('VK Load Error:', e); return null; });
    }
    return Promise.resolve(null);
}

function showFullscreenAd(callback) {
    if (!vkAvailable || !window.vkBridge) { if (callback) callback(); return; }
    const wasPlaying = game.state === 'playing';
    if (wasPlaying) {
        game.state = 'ad';
        if (audioCtx && audioCtx.state === 'running') audioCtx.suspend();
    }
    let called = false;
    const once = () => { if (called) return; called = true; if (callback) callback(); };

    window.vkBridge.send('VKWebAppShowNativeAds', { ad_format: 'interstitial' })
        .then(() => { if (audioCtx && audioCtx.state === 'suspended' && soundEnabled) audioCtx.resume(); once(); })
        .catch(() => { if (audioCtx && audioCtx.state === 'suspended' && soundEnabled) audioCtx.resume(); once(); });
}

function showRewardedAd(onSuccess, onFail) {
    if (!vkAvailable || !window.vkBridge) { if (onFail) onFail(); return; }
    if (game.rewardAdUsedThisLevel) { alert('Реклама за вознаграждение доступна только 1 раз за уровень!'); if (onFail) onFail(); return; }

    window.vkBridge.send('VKWebAppShowNativeAds', { ad_format: 'reward', use_waterfall: true })
        .then((data) => {
            if (data.result) { game.rewardAdUsedThisLevel = true; if (onSuccess) onSuccess(); }
            else { if (onFail) onFail(); }
        })
        .catch((error) => { console.log('Rewarded Ad Error:', error); if (onFail) onFail(); });
}

function showLeaderboard() {
    if (!vkAvailable || !window.vkBridge) { alert('Таблица рекордов доступна только в приложении VK!'); return; }
    window.vkBridge.send('VKWebAppShowLeaderBoardBox', { user_result: game.highScore })
        .then((data) => { console.log('Leaderboard opened:', data.success); })
        .catch((error) => { console.log('Leaderboard Error:', error); });
}

function saveHighScore(score) {
    if (score > game.highScore) {
        game.highScore = score;
        try { localStorage.setItem('monster_shot_highscore', score); } catch(e) {}
    }
}

function initVKSdk() {
    const hidePreloader = () => {
        const preloader = document.getElementById('preloader');
        if (preloader) { preloader.style.opacity = '0'; setTimeout(() => preloader.style.display = 'none', 300); }
    };

    try { const hs = localStorage.getItem('monster_shot_highscore'); if (hs) game.highScore = parseInt(hs); } catch(e) {}

    if (window.location.protocol === 'file:' || typeof window.vkBridge === 'undefined') {
        hidePreloader(); return Promise.resolve();
    }

    return window.vkBridge.send('VKWebAppInit')
        .then(() => {
            vkAvailable = true;
            try {
                window.vkBridge.subscribe((e) => {
                    if (e.detail.type === 'VKWebAppViewHide') {
                        if (audioCtx && audioCtx.state === 'running') audioCtx.suspend();
                        if (game.state === 'playing') pauseGame();
                    }
                    if (e.detail.type === 'VKWebAppViewRestore') {
                        if (audioCtx && audioCtx.state === 'suspended' && soundEnabled) audioCtx.resume();
                    }
                });
            } catch(err) {}
            return window.vkBridge.send('VKWebAppGetUserInfo');
        })
        .then(userInfo => { vkData = userInfo; return loadProgress(); })
        .then(savedData => { game.savedProgress = savedData; hidePreloader(); })
        .catch(err => { vkAvailable = false; console.log('VK init error:', err); hidePreloader(); });
}
// ===== АНАЛИТИКА =====
function trackEvent(eventName, params = {}) {
    // Добавляем версию и текущий уровень/волну по умолчанию
    params.version = GAME_VERSION;
    params.mode = game.mode;
    if (game.mode === 'campaign') params.level = game.level;
    if (game.mode === 'survival') params.wave = game.wave;

    console.log(`📊 [Analytics] ${eventName}:`, params);

    // Отправка в VK (если есть)
    if (vkAvailable && window.vkBridge) {
        window.vkBridge.send('VKWebAppTrackEvent', {
            event_name: eventName,
            event_data: params
        }).catch(e => console.log('VK Analytics Error:', e));
    }
    
    // Отправка в Яндекс.Метрику
    if (typeof ym !== 'undefined' && typeof METRIKA_ID !== 'undefined') {
        // Передаем имя события и параметры (доступны в отчетах Метрики)
        ym(METRIKA_ID, 'reachGoal', eventName, params);
    }
}