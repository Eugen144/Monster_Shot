function resize() {
    W = window.innerWidth; H = window.innerHeight;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener('resize', resize);
window.addEventListener('orientationchange', () => setTimeout(resize, 200));
resize();

// Загрузка локальных рекордов выживания
try {
    const w = localStorage.getItem('monster_shot_survival_wave');
    if (w) game.survivalHighWave = parseInt(w) || 0;
    const s = localStorage.getItem('monster_shot_survival_score');
    if (s) game.survivalHighScore = parseInt(s) || 0;
} catch(e) {}

document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        if (audioCtx && audioCtx.state === 'running') audioCtx.suspend();
        if (game.state === 'playing') pauseGame();
    } else { if (audioCtx && audioCtx.state === 'suspended' && soundEnabled) audioCtx.resume(); }
});
window.addEventListener('blur', () => { if (audioCtx && audioCtx.state === 'running') audioCtx.suspend(); });
window.addEventListener('focus', () => { if (audioCtx && audioCtx.state === 'suspended' && soundEnabled) audioCtx.resume(); });
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('selectstart', e => { if (e.target && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') e.preventDefault(); });

function resumeAudioOnGesture() {
    if (audioCtx && audioCtx.state === 'suspended' && soundEnabled) {
        audioCtx.resume().catch(() => {});
    }
}
window.addEventListener('click', resumeAudioOnGesture);
window.addEventListener('touchstart', resumeAudioOnGesture, { passive: true });
window.addEventListener('keydown', resumeAudioOnGesture);

function setupMobileControls() {
    if (!isMobile) return;

    const elJoy   = document.getElementById('joystick-container');
    const elShoot = document.getElementById('shoot-joystick-container');
    const elInv   = document.getElementById('inv-btn-mobile');
    if (elJoy)   elJoy.classList.remove('hidden');
    if (elShoot) elShoot.classList.remove('hidden');
    if (elInv)   elInv.classList.remove('hidden');

    // ---------- ПРАВЫЙ ДЖОЙСТИК (СТРЕЛЬБА + ПРИЦЕЛ) ----------
    const shootJoystickContainer = document.getElementById('shoot-joystick-container');
    const shootJoystickBase      = document.getElementById('shoot-joystick-base');
    const shootJoystickStick     = document.getElementById('shoot-joystick-stick');

    if (shootJoystickContainer && shootJoystickBase) {
        let shootTouchId = null;

        const handleShootMove = (touch) => {
            const rect = shootJoystickBase.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            let dx = touch.clientX - centerX;
            let dy = touch.clientY - centerY;
            const dist = Math.hypot(dx, dy);
            const maxDist = rect.width / 2 - 28;
            
            // Вычисляем силу нажатия (от 0 до 1) ДО обрезки
            const force = Math.min(dist / maxDist, 1.0);
            // Проверяем, превышен ли порог для стрельбы (используем константу из конфига)
            const isShooting = force > SHOOT_FORCE_THRESHOLD;

            if (dist > maxDist) {
                dx = (dx / dist) * maxDist;
                dy = (dy / dist) * maxDist;
            }
            
            if (shootJoystickStick) {
                shootJoystickStick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
                
                // Визуальный фидбек: стик становится белым, когда начинается стрельба
                if (isShooting) {
                    shootJoystickStick.style.background = 'rgba(255, 255, 255, 0.95)';
                    shootJoystickStick.style.boxShadow = '0 0 30px #fff, 0 0 15px #ff0044';
                } else {
                    shootJoystickStick.style.background = 'rgba(255, 0, 68, 0.9)';
                    shootJoystickStick.style.boxShadow = '0 0 20px #ff0044';
                }
            }
            
            shootJoystickVector.x = dx / maxDist;
            shootJoystickVector.y = dy / maxDist;

            // Поворот игрока (работает всегда, даже при легком нажатии)
            if (game.player && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) {
                game.player.angle = Math.atan2(dy, dx);
                const screenPlayerX = game.player.x - game.camX;
                const screenPlayerY = game.player.y - game.camY;
                crosshair.style.left = (screenPlayerX + Math.cos(game.player.angle) * 100) + 'px';
                crosshair.style.top  = (screenPlayerY + Math.sin(game.player.angle) * 100) + 'px';
            }

            // Стрельба только при сильном нажатии
            if (isShooting) {
                shootJoystickTrigger = true;
                if (game.state === 'playing') shoot();
            } else {
                shootJoystickTrigger = false;
            }
        };

        shootJoystickContainer.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.changedTouches[0];
            shootTouchId = touch.identifier;
            shootJoystickActive = true;
            shootJoystickTrigger = false; 
            game.mouseDown = false; // Отключаем ПК-шный флаг, чтобы не было двойной стрельбы
            handleShootMove(touch);
        }, { passive: false });

        shootJoystickContainer.addEventListener('touchmove', (e) => {
            e.preventDefault();
            if (!shootJoystickActive) return;
            for (let i = 0; i < e.changedTouches.length; i++) {
                if (e.changedTouches[i].identifier === shootTouchId) {
                    handleShootMove(e.changedTouches[i]);
                    break;
                }
            }
        }, { passive: false });

        const endShootJoystick = (e) => {
            e.preventDefault();
            shootJoystickActive = false;
            shootJoystickTrigger = false;
            shootJoystickVector = { x: 0, y: 0 };
            game.mouseDown = false;
            
            if (shootJoystickStick) {
                shootJoystickStick.style.transform = 'translate(-50%, -50%)';
                shootJoystickStick.style.background = 'rgba(255, 0, 68, 0.9)';
                shootJoystickStick.style.boxShadow = '0 0 20px #ff0044';
            }
            
            if (game.player) {
                game.mouseX = (game.player.x - game.camX) + Math.cos(game.player.angle) * 100;
                game.mouseY = (game.player.y - game.camY) + Math.sin(game.player.angle) * 100;
            }
            shootTouchId = null;
        };
        shootJoystickContainer.addEventListener('touchend', endShootJoystick, { passive: false });
        shootJoystickContainer.addEventListener('touchcancel', endShootJoystick, { passive: false });
    }

    // ---------- ЛЕВЫЙ ДЖОЙСТИК (ДВИЖЕНИЕ) ----------
    const joystickContainer = document.getElementById('joystick-container');
    const joystickBase      = document.getElementById('joystick-base');
    const joystickStick     = document.getElementById('joystick-stick');

    if (joystickContainer && joystickBase) {
        let touchId = null;

        joystickContainer.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.changedTouches[0];
            touchId = touch.identifier;
            joystickActive = true;
            handleJoystickMove(touch);
        }, { passive: false });

        joystickContainer.addEventListener('touchmove', (e) => {
            e.preventDefault();
            if (!joystickActive) return;
            for (let i = 0; i < e.changedTouches.length; i++) {
                if (e.changedTouches[i].identifier === touchId) {
                    handleJoystickMove(e.changedTouches[i]);
                    break;
                }
            }
        }, { passive: false });

        const endJoystick = (e) => {
            e.preventDefault();
            joystickActive = false;
            joystickVector = { x: 0, y: 0 };
            if (joystickStick) joystickStick.style.transform = 'translate(-50%, -50%)';
            touchId = null;
        };
        joystickContainer.addEventListener('touchend', endJoystick, { passive: false });
        joystickContainer.addEventListener('touchcancel', endJoystick, { passive: false });

        function handleJoystickMove(touch) {
            const rect = joystickBase.getBoundingClientRect();
            const centerX = rect.left + rect.width / 2;
            const centerY = rect.top + rect.height / 2;
            let dx = touch.clientX - centerX;
            let dy = touch.clientY - centerY;
            const dist = Math.hypot(dx, dy);
            const maxDist = rect.width / 2 - 28;
            if (dist > maxDist) { dx = (dx / dist) * maxDist; dy = (dy / dist) * maxDist; }
            joystickStick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
            joystickVector.x = dx / maxDist;
            joystickVector.y = dy / maxDist;
        }
    }

    // ---------- КНОПКИ ----------
    const invBtn = document.getElementById('inv-btn-mobile');
    if (invBtn) invBtn.addEventListener('touchstart', (e) => { e.preventDefault(); toggleInventory(); }, { passive: false });

    const menuBtn = document.getElementById('menu-btn-mobile');
    if (menuBtn) menuBtn.addEventListener('touchstart', (e) => { e.preventDefault(); togglePause(); }, { passive: false });

    canvas.addEventListener('touchstart', (e) => {
        if (game.state !== 'playing') return;
        const touch = e.touches[0];
        if (!touch) return;
        const target = document.elementFromPoint(touch.clientX, touch.clientY);
        if (target === canvas) {
            game.mouseX = touch.clientX;
            game.mouseY = touch.clientY;
            crosshair.style.left = touch.clientX + 'px';
            crosshair.style.top  = touch.clientY + 'px';
        }
    }, { passive: true });

    canvas.addEventListener('touchmove', (e) => {
        if (game.state !== 'playing') return;
        const touch = e.touches[0];
        if (!touch) return;
        game.mouseX = touch.clientX;
        game.mouseY = touch.clientY;
        crosshair.style.left = touch.clientX + 'px';
        crosshair.style.top  = touch.clientY + 'px';
    }, { passive: true });
}

window.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase();
    if (e.repeat) { game.keys[key] = true; return; }
    if (e.key === 'Escape' || key === 'esc' || key === 'p' || key === 'з') {
        e.preventDefault();
        if (game.state === 'inventory') closeInventory();
        else togglePause();
        return;
    }
    game.keys[key] = true;
    if ((key === 'e' || key === 'у') && (game.state === 'playing' || game.state === 'inventory')) {
        e.preventDefault();
        toggleInventory();
    }
});
window.addEventListener('keyup', (e) => { game.keys[e.key.toLowerCase()] = false; });

canvas.addEventListener('mousemove', (e) => {
    game.mouseX = e.clientX;
    game.mouseY = e.clientY;
    crosshair.style.left = e.clientX + 'px';
    crosshair.style.top  = e.clientY + 'px';
});
canvas.addEventListener('mousedown', (e) => {
    if (e.button === 0 && game.state === 'playing') { game.mouseDown = true; shoot(); }
});
canvas.addEventListener('mouseup', () => { game.mouseDown = false; });

// Автоматическая стрельба при удержании (для ПК и мобилок с активированным триггером)
setInterval(() => {
    if (game.state !== 'playing') return;
    const shooting = game.mouseDown
        || (isMobile && shootJoystickActive && shootJoystickTrigger);
    if (shooting) shoot();
}, 50);

document.getElementById('btn-continue').addEventListener('click', () => {
    let s = game.savedProgress || {};
    try { const local = localStorage.getItem('monster_shot_save'); if (local) s = JSON.parse(local); } catch(e) {}
    let lvl = s.level !== undefined ? Number(s.level) : 0;
    if (lvl === 0 && (s.totalCoins > 0 || (s.ownedWeapons && s.ownedWeapons.length > 1))) lvl = 1;
    launchGame(lvl, false);
});

document.getElementById('btn-new-game').addEventListener('click', () => {
    document.getElementById('menu').classList.add('hidden');
    document.getElementById('new-game-menu').classList.remove('hidden');
});

document.getElementById('btn-campaign').addEventListener('click', () => {
    launchGame(1, true);
});

document.getElementById('btn-survival').addEventListener('click', () => {
    startSurvival();
});

document.getElementById('btn-back-to-menu').addEventListener('click', () => {
    document.getElementById('new-game-menu').classList.add('hidden');
    document.getElementById('menu').classList.remove('hidden');
});

document.getElementById('btn-tutorial').addEventListener('click', () => launchGame(0, true));

document.getElementById('btn-leaderboard').addEventListener('click', showLeaderboard);

// Кнопка рекордов выживания
document.getElementById('btn-survival-records').addEventListener('click', showSurvivalRecords);
document.getElementById('btn-close-records').addEventListener('click', () => {
    document.getElementById('survival-records-modal').classList.add('hidden');
});
document.getElementById('btn-survival-leaderboard').addEventListener('click', showSurvivalLeaderboard);

document.getElementById('btn-support').addEventListener('click', () => {
    if (vkAvailable && window.vkBridge) {
        window.vkBridge.send('VKWebAppJoinGroup', { group_id: 242108226 }).catch(() => { window.open(SUPPORT_URL, '_blank'); });
    } else { window.open(SUPPORT_URL, '_blank'); }
});

document.getElementById('btn-devs').addEventListener('click', () => { document.getElementById('devs-modal').classList.remove('hidden'); });
document.getElementById('btn-close-devs').addEventListener('click', () => { document.getElementById('devs-modal').classList.add('hidden'); });

document.getElementById('shop-open-btn').addEventListener('click', openShop);
document.getElementById('shop-next-btn').addEventListener('click', nextLevel);
document.getElementById('menu-from-level-btn').addEventListener('click', returnToMenu);
document.getElementById('restart-btn').addEventListener('click', restartLevel);
document.getElementById('menu-from-gameover-btn').addEventListener('click', returnToMenu);
document.getElementById('victory-restart-btn').addEventListener('click', () => launchGame(1, true));
document.getElementById('menu-from-victory-btn').addEventListener('click', returnToMenu);
document.getElementById('pause-resume-btn').addEventListener('click', resumeGame);
document.getElementById('pause-restart-btn').addEventListener('click', () => { document.getElementById('pause').classList.add('hidden'); restartLevel(); });
document.getElementById('pause-menu-btn').addEventListener('click', () => { document.getElementById('pause').classList.add('hidden'); returnToMenu(); });
document.getElementById('sound-btn').addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    updateSoundButton();
    if (soundEnabled) {
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
        playSound(800, 0.1, 'sine');
    }
    try { localStorage.setItem('soundEnabled', soundEnabled ? '1' : '0'); } catch (e) {}
});

document.getElementById('levelup-continue-btn').addEventListener('click', () => {
    document.getElementById('survival-levelup').classList.add('hidden');
    game.state = 'playing';
    game.keys = {};
    game.mouseDown = false;
    joystickActive = false;
    joystickVector = {x:0, y:0};
    shootJoystickActive = false;
    shootJoystickTrigger = false;
    shootJoystickVector = {x:0, y:0};
});

document.getElementById('levelup-ad-btn').addEventListener('click', () => {
    showRewardedAd(
        () => {
			// Добавляем трекинг успешного просмотра
            trackEvent('Ad_Watched', { context: 'survival_levelup' });
			
            game.levelupAdUsed = true;
            game.levelupPicksLeft = 1;
            renderLevelUpCards();
            document.getElementById('levelup-ad-btn').style.display = 'none';
        },
        () => { alert('Реклама недоступна или закрыта.'); }
    );
});

try { const saved = localStorage.getItem('soundEnabled'); if (saved === '0') soundEnabled = false; } catch (e) {}
updateSoundButton();

// ===== Версия игры в интерфейсе =====
const versionEl = document.getElementById('game-version');
if (versionEl) versionEl.textContent = GAME_VERSION;
const devsVersionEl = document.getElementById('devs-version');
if (devsVersionEl) devsVersionEl.textContent = GAME_VERSION;

let lastTime = performance.now();

function loop(now) {
    const dt = Math.min((now - lastTime) / 1000, 0.05);
    lastTime = now;

    if (game.state === 'playing' || game.state === 'inventory') {
        update(dt);
    }

    if (game.state === 'menu') {
        ctx.fillStyle = (game.palette && game.palette.bg) ? game.palette.bg : '#1a1a2e';
        ctx.fillRect(0, 0, W, H);
    } else {
        draw();
    }

    requestAnimationFrame(loop);
}

initTutorialUI();

initVKSdk()
    .catch(err => console.warn('VK SDK init error:', err))
    .finally(() => {
        setupMobileControls();
        requestAnimationFrame(loop);
    });